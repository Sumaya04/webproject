<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'indoor_plants');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// Fetch user details
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_email = $conn->real_escape_string($_POST['email']);
    $new_username = $conn->real_escape_string($_POST['username']);
    
    // Directly update the password without hashing
    $new_password = !empty($_POST['password']) ? $conn->real_escape_string($_POST['password']) : $user['password'];

    $sql = "UPDATE users SET email = '$new_email', username = '$new_username', password = '$new_password' WHERE username = '$username'";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['username'] = $new_username; // Update session username
        echo "<script>alert('Profile updated successfully!');</script>";
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Profile</title>
    <script src="script.js" defer></script>
</head>
<body>
    <header>
        <nav>
            <a href="index.html">Home</a>
            <a href="cart.html">Cart</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <main>
        <section class="profile-section">
            <h1>Your Profile</h1>
            <form id="profileForm" action="profile.php" method="POST">
                <label for="username">Username:</label>
                <input style="color:black" type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                
                <label for="email">Email:</label>
                <input style="color:black" type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                
                <label for="password">New Password:</label>
                <input style="color:black" type="text" id="password" name="password" value="<?php echo htmlspecialchars($user['password']); ?>" placeholder="Leave blank to keep current password" required>
                
                <button style="color:black"type="submit">Update Profile</button>
            </form>
        </section>
    </main>
</body>
</html>
