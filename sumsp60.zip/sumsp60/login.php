<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'indoor_plants');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']); // Plain text password

    // Fetch user data
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Compare the plain text password
        if ($password === $user['password']) { // Direct comparison for plain text
            session_start();
            $_SESSION['username'] = $user['username'];

            // Redirect to profile.php after successful login
            header("Location: profile.php");
            exit(); // Ensure no further code executes
        } else {
            echo "Invalid username or password.";
        }
    } else {
        echo "Invalid username or password.";
    }
}

$conn->close();
?>
