<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "your_database_name");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from URL
if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // SQL to delete the user
    $sql = "DELETE FROM users WHERE id = $user_id";

    if ($conn->query($sql) === TRUE) {
        echo "User deleted successfully. <a href='user_list.php'>Go Back</a>";
    } else {
        echo "Error deleting user: " . $conn->error;
    }
} else {
    echo "Invalid Request.";
}

$conn->close();
?>
