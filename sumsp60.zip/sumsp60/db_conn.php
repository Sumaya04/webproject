<?php

$name= "localhost";
$email= "root";
$password = "";

$db_name = "indoor_plants";

$conn = mysqli_connect($username, $email, $password, $db_name);

if (!$conn) {
	echo "Connection failed!";
}